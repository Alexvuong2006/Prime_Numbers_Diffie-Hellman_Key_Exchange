# Thư mục Kiểm thử (Tests & Benchmarks)

Phụ trách chính: **Tạ Quang Mạnh (24120089)**. Phần kiểm thử `BigInt` cơ bản do **Khang (24120070)** viết sẵn.

> Thư mục này chỉ phục vụ kiểm thử nội bộ trên GitHub, **không đưa vào file zip khi nộp bài**.

## Các file hiện có

| File | Mô tả | Trạng thái |
|---|---|:---:|
| `test_bigint.cpp` | Unit test `BigInt`: chuyển đổi hex/dec, so sánh, `+ - *`, dịch bit, `mod_small`, chia/mod | ✅ |
| `crosscheck_bigint.cpp` | Chương trình C++ đọc lệnh từ stdin (`add/sub/mul/div/mod/shl/shr/dec/bl/msm`) và in kết quả; cuối chương trình đo tốc độ `mulmod` 512-bit | ✅ |
| `crosscheck_bigint.py` | Script sinh 30.000 phép tính ngẫu nhiên, chạy `crosscheck_bigint` rồi đối chiếu với số nguyên Python. Python **chỉ làm đáp án chuẩn**, không thuộc chương trình nộp | ✅ |

## Cách chạy

Chạy từ thư mục `tests/` (cần g++ hỗ trợ C++14; Windows dùng MSYS2 UCRT64):

```bash
# 1) Unit test BigInt
g++ -std=c++14 -O2 -Wall -Wextra -o test_bigint test_bigint.cpp
./test_bigint

# 2) Đối chiếu với Python (cần Python 3)
g++ -std=c++14 -O2 -o crosscheck_bigint crosscheck_bigint.cpp
python crosscheck_bigint.py ./crosscheck_bigint     # kỳ vọng: "mismatch 0"
```

Sau mỗi lần sửa `bigint.cpp` (đặc biệt khi tối ưu `divmod` bằng Knuth D), **phải chạy lại cả hai** và giữ kết quả `mismatch 0`.

## Các file do Mạnh bổ sung

| File | Mô tả |
|---|---|
| `crosscheck_div_stress.py` | 50.016 phép chia/mod với số cạnh biên (limb 0, 2^63, 2^64-1…), ép đi qua nhánh hiệu chỉnh q_hat và add-back của Knuth D. Dùng chung binary `crosscheck_bigint` |
| `crosscheck_modexp.cpp/.py` | Đối chiếu `modular_exponentiation` với `pow(b, e, m)` của Python (4.452 ca) |
| `test_dh.cpp` | Unit test modexp, `choose_generator`, `is_valid_public_value`, DH nhiều lần (seed cố định + ngẫu nhiên) trên safe prime 512 bit và Oakley Group 2 (RFC 2409, 1024 bit). **Không phụ thuộc `prime.cpp`** |
| `test_prime.cpp` | Test phần của Minh: `random_bits`, `random_range`, Miller-Rabin (số Carmichael, Mersenne, Oakley2), `generate_safe_prime`, `generate_private_key`. Chạy được sau khi `prime.cpp` hoàn thiện |
| `bench_modexp.cpp` | Đo `mulmod` và `modular_exponentiation` ở 512/768/1024 bit |

Lệnh chạy (tại `tests/`):

```bash
g++ -std=c++14 -O2 -o crosscheck_bigint crosscheck_bigint.cpp
python crosscheck_bigint.py ./crosscheck_bigint          # mismatch 0
python crosscheck_div_stress.py ./crosscheck_bigint      # mismatch 0

g++ -std=c++14 -O2 -o crosscheck_modexp crosscheck_modexp.cpp
python crosscheck_modexp.py ./crosscheck_modexp          # mismatch 0

g++ -std=c++14 -O2 -Wall -Wextra -o test_dh test_dh.cpp && ./test_dh
g++ -std=c++14 -O2 -Wall -Wextra -o test_prime test_prime.cpp && ./test_prime   # sau khi Minh xong
g++ -std=c++14 -O2 -o bench_modexp bench_modexp.cpp && ./bench_modexp
```

> Ghi chú: RFC 3526 nhỏ nhất là 1536 bit, lớn hơn `MAX_PRIME_BITS` (1024) nên test dùng Oakley Group 2 (RFC 2409, 1024 bit) thay thế.

## Kết quả hiện tại (Mạnh)

- `mulmod` 512 bit: 72 µs (chia nhị phân) -> 0,44 µs (Knuth D). `modexp` 512 bit ≈ 0,24 ms.
- `crosscheck_bigint`: 30.000 phép, 0 sai lệch. `crosscheck_div_stress`: 50.016 phép, 0 sai lệch. `crosscheck_modexp`: 4.452 ca, 0 sai lệch.
- `test_dh`: tất cả qua.

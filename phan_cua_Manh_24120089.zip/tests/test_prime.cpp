// ============================================================================
// test_prime.cpp - Kiem thu phan cua Minh: random_bits, random_range, is_probable_prime,
// generate_safe_prime, generate_private_key.
// Bien dich: g++ -std=c++14 -O2 -Wall -Wextra -o test_prime test_prime.cpp && ./test_prime
// Dung cung vector da xac thuc bang Python nhu test_dh.cpp. Bao loi qua GitHub Issues.
// ============================================================================
#include <iostream>
#include <cassert>
#include <string>
#include <chrono>
#include "../project_01_source/fips202.cpp"
#include "../project_01_source/prng.cpp"
#include "../project_01_source/bigint.cpp"
#include "../project_01_source/dh.cpp"
#include "../project_01_source/prime.cpp"

static big_t H(const char *s) { return big_t::from_hex(s); }
static big_t U(uint64_t v) { return big_t::from_u64(v); }
static const char *OAKLEY2 =
    "ffffffffffffffffc90fdaa22168c234c4c6628b80dc1cd129024e088a67cc74"
    "020bbea63b139b22514a08798e3404ddef9519b3cd3a431b302b0a6df25f1437"
    "4fe1356d6d51c245e485b576625e7ec6f44c42e9a637ed6b0bff5cb6f406b7ed"
    "ee386bfb5a899fa5ae9f24117c4b1fe649286651ece65381ffffffffffffffff";

static void seeded(prng_ctx *ctx)
{
    uint8_t seed[32];
    for (int i = 0; i < 32; i++) seed[i] = (uint8_t)(255 - i * 3);
    prng_seed(ctx, seed, sizeof(seed));
}

static void test_random(prng_ctx *ctx)
{
    std::cout << "[Test] random_bits / random_range...\n";
    for (size_t bits : {1, 2, 63, 64, 65, 127, 512, 513, 1000, 1024}) {
        for (int i = 0; i < 50; i++) {
            big_t r = random_bits(ctx, bits);
            assert(r.bit_length() == bits); // dung `bits` bit, bit cao nhat = 1
        }
    }
    big_t lo = U(2), hi = U(10);
    bool seen[11] = {false};
    for (int i = 0; i < 2000; i++) {
        big_t r = random_range(ctx, lo, hi);
        assert(r >= lo && r <= hi);
        seen[r.digits[0]] = true;
    }
    for (int v = 2; v <= 10; v++) assert(seen[v]); // phu het doan [2, 10]
    big_t p = H(OAKLEY2);
    for (int i = 0; i < 200; i++) {
        big_t k = generate_private_key(ctx, p);
        assert(k >= U(2) && k <= p - U(2));
    }
    assert(random_range(ctx, U(5), U(5)) == U(5)); // doan 1 phan tu
    std::cout << "  => PASS\n";
}

static void test_miller_rabin(prng_ctx *ctx)
{
    std::cout << "[Test] is_probable_prime (Miller-Rabin)...\n";
    uint64_t primes[] = {2, 3, 5, 7, 11, 97, 7919, 1000003, 2147483647ULL, (1ULL << 61) - 1, 18446744073709551557ULL};
    for (uint64_t x : primes) assert(is_probable_prime(ctx, U(x), 20));
    uint64_t comps[] = {0, 1, 4, 6, 9, 15, 91, 1000001, 3215031751ULL, 4294967297ULL /* 641*6700417 */};
    for (uint64_t x : comps) assert(!is_probable_prime(ctx, U(x), 20));
    // so Carmichael: Fermat bi lua, Miller-Rabin khong
    uint64_t carm[] = {561, 1105, 1729, 2465, 2821, 6601, 41041, 825265, 321197185ULL, 5394826801ULL};
    for (uint64_t x : carm) assert(!is_probable_prime(ctx, U(x), 20));
    // nguyen to Mersenne 2^127-1, 2^521-1 va hop so 2^127+1 (chia het cho 3)
    big_t one = U(1);
    assert(is_probable_prime(ctx, (one << 127) - one, 20));
    assert(is_probable_prime(ctx, (one << 521) - one, 20));
    assert(!is_probable_prime(ctx, (one << 127) + one, 20));
    assert(!is_probable_prime(ctx, (one << 128) - one, 20)); // 2^128 - 1 = 3*5*17*257*...
    // Oakley Group 2 la safe prime: p va q = (p-1)/2 deu nguyen to
    big_t p = H(OAKLEY2);
    assert(is_probable_prime(ctx, p, 40));
    assert(is_probable_prime(ctx, (p - one) >> 1, 40));
    assert(!is_probable_prime(ctx, p - U(2), 40));
    // tich hai nguyen to lon (semiprime 2 x 61 bit va 2^127-1 nhan 2^61-1)
    assert(!is_probable_prime(ctx, ((one << 127) - one) * U((1ULL << 61) - 1), 40));
    std::cout << "  => PASS\n";
}

static void test_safe_prime(prng_ctx *ctx)
{
    std::cout << "[Test] generate_safe_prime...\n";
    for (size_t bits : {32, 64, 128, 256}) {
        auto t0 = std::chrono::steady_clock::now();
        big_t p = generate_safe_prime(ctx, bits);
        double s = std::chrono::duration<double>(std::chrono::steady_clock::now() - t0).count();
        big_t q = (p - U(1)) >> 1;
        assert(p.bit_length() == bits && p.is_odd());
        assert(is_probable_prime(ctx, p, 40) && is_probable_prime(ctx, q, 40));
        std::cout << "    " << bits << " bit: " << s << " s, p = " << p.to_hex() << "\n";
    }
    std::cout << "  => PASS (Benchmark 512/768/1024 bit: chay ./dh --bits <n>)\n";
}

int main()
{
    prng_ctx ctx;
    seeded(&ctx);
    test_random(&ctx);
    test_miller_rabin(&ctx);
    test_safe_prime(&ctx);
    std::cout << "ALL PRIME TESTS PASSED\n";
    return 0;
}

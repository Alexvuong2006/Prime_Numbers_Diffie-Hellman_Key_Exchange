# Thư mục nháp Báo cáo

Thư mục này dùng để các thành viên soạn thảo bản nháp các mục báo cáo trước khi tổng hợp thành file PDF hoàn chỉnh (`report.pdf` trong `project_01_report/`).

## Phân công viết báo cáo:
- **[Mục 1: Hệ thống xử lý số lớn](muc1_he_thong_so_lon.md)** - Khang (chính) & Mạnh (phần chia/mod, modular_exponentiation) - *[Đã hoàn thành bản thảo của Khang]* + **[phần bổ sung chia/mod & modexp của Mạnh](muc1_bo_sung_chia_modexp.md)** - *[Đã xong bản thảo]*
- **Mục 2: Các thuật toán kiểm tra số nguyên tố** - Minh
- **Mục 3: Số ngẫu nhiên & ứng dụng trong mật mã (điểm cộng)** - Minh
- **[Mục 4: Ứng dụng thực tế của Diffie-Hellman](muc4_ung_dung_dh.md)** - Mạnh - *[Đã xong bản thảo]*
- **[Mục 5: Mô tả chương trình & hướng dẫn sử dụng](muc5_mo_ta_chuong_trinh.md)** - Khang - *[Đã hoàn thành bản thảo]*
- **Mục 6: Tự đánh giá ưu/nhược điểm & hướng cải thiện** - Cả 3 thành viên (Khang tổng hợp)

*Lưu ý: Thư mục này chỉ phục vụ làm việc nội bộ nhóm trên GitHub, không đưa vào file zip khi nộp bài.*
